tinyMCE.addI18n('it.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"Senza ombreggiatura"
});