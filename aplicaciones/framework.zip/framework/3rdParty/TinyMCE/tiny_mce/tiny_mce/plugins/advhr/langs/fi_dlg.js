tinyMCE.addI18n('fi.advhr_dlg',{
width:"Leveys",
size:"Korkeus",
noshade:"Ei varjoa"
});