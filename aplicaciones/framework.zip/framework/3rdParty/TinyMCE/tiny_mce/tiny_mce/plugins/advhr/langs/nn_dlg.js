tinyMCE.addI18n('nn.advhr_dlg',{
width:"Breidd",
size:"Storleik",
noshade:"Inga skugge"
});